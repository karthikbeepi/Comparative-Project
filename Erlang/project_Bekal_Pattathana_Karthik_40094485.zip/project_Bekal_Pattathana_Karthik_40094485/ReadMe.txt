For Erlang
=> Please run the money:start() to start running the program after compiling all .erl files.
=> (Tested using the command : erl -noshell -s money start -s init stop  in an Ubuntu Environment)
=> After waiting for 2.5 seconds, the program will return main_program_exiting as a return value.
=> The customer will request an amount equivalent to Random of 50 and the current loan objective of the customer(whichever is smaller).

For Java,
=> First compile all the java files in the folder.
=> Please run the money.java file but provide the required files in the current directory.